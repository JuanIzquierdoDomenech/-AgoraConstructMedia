/////////////////////////
//HOW TO USE THIS ASSET//
/////////////////////////

Hello, fellow game developer! Thank you for downloading the Valiant Knight asset pack. Here are a few pointers to help you navigate and make sense of this zip file.

Tips:

- Each animation has its own folder.

- Alternatively, a spritesheet can be found in the spritesheet folder, along with two metadata files. (Pick the format you like.)

- Block effects have their own spritesheet folder, located at effect/spritesheet.

- The recommended frame duration is 75 ms/frame (equivalent to 15 frames/sec).

Got questions? Hit me up at:
@untiedgames (twitter)
contact@untiedgames.com (email)

Thanks again! Check out more of my asset packs at http://untiedgames.com/assets.
-Will
