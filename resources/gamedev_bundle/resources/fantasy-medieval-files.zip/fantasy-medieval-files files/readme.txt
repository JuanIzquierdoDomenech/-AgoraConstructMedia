Read me File

Thanks for purchasing this Art Asset Pack hope you find it useful.

The downloadable file contains everything you need to start working right away on your project. I have included all the elements in transparent PNG files. 

- Contents

-- Backgrounds Folder: Contains the ready to use PNG files for the background. They are all seamless loopable 

-- Tilesets: Contains the png files for the elements, individually or as a spritesheet.




Thanks Again

Visit my site for free resources at www.ansimuz.com