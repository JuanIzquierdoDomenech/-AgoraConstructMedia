These pixel fonts will reproduce cleanly at the following sizes:

8x8 fonts will reproduce cleanly in multiples of 8 points at 72 DPI or multiples of 8 pixels unless otherwise stated.
BlueSky 8x8 and Bluesky 8x8 Monospaced will reproduce cleanly in multiples of 7 point at 72 DPI or multiples of 7 pixels.

8x16 fonts will reproduce cleanly in multiples of 13 points at 72 DPI or multiples of 13 pixels unless otherwise stated.
